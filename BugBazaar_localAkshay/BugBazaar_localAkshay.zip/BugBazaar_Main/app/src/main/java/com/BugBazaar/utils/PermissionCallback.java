package com.BugBazaar.utils;

public interface PermissionCallback {
    void onPermissionGranted();
    void onPermissionDenied();
}

